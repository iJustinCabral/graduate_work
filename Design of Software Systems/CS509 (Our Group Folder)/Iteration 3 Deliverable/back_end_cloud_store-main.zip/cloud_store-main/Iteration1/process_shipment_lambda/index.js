let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
})

pool.query = util.promisify(pool.query);

//-------------------------------------------------------
exports.handler = async (event, context, callback) => {
    try {
        let actual_event = event.body;
        let info = JSON.parse(actual_event);
        
        //Grab the store the manager belongs to.
        var store = await pool.query(`select * from Stores where managerID="${info.managerID}";`);
        var storeID = store[0].storeID;
        
        //Process the items being sent.
        for (var processItem of info.items) {
            var sku = String(processItem.sku); //Grab the sku for item we are going to process.
            var processQty = parseInt(processItem.qty); //Grab the quantity that needs to be processed.
    
            var shelfMaxQty = await pool.query(`select shelfMaxQty from Items where sku="${sku}";`); //Grab the max allowed on a shelf for the item.
            shelfMaxQty = shelfMaxQty[0].shelfMaxQty;
            
            //Grab all the locations in the store where the item is placed.
            var itemPlacementsInStore = await pool.query(`select * from Placements where sku="${sku}" and storeID=${storeID};`)
            
            //Check each location in the store to see if we can put the items there.
            for(var i = 0; i < itemPlacementsInStore.length; i++){
                var aisle = itemPlacementsInStore[i].aisle; //Grab aisle for this location
                var shelf = itemPlacementsInStore[i].shelf;//Grab shelf for this location
                var currQty = itemPlacementsInStore[i].shelfQty; //Grab the current Qty in this location.
                
                var error = parseInt(shelfMaxQty) - (parseInt(currQty) + parseInt(processQty)); //See if you can fit the amount to be processed in this location.
                console.log("Space left on the aisle/shelf" + ":" + error); //How much space left
                
                //If no more space
                if (error <= 0) {
                    
                    await pool.query(`update Placements set shelfQty=${shelfMaxQty} where sku="${sku}" and storeID=${storeID} and aisle=${aisle} and shelf=${shelf};`)
                    
                    processQty = Math.abs(error)//amount left over still needs to be processed.
                    
                    //If no more locations in the store where this item is placed or if the item was fully processed.
                    if(i === (itemPlacementsInStore.length-1) || processQty === 0){
                        //check to see if there is an overstock record for this item at this store.
                        var overstock = await pool.query(`select * from Overstock where sku="${sku}" and storeID=${storeID};`)
                        
                        //if there isnt an overstock record we create one and put the remainder of the shipment for this item there.
                        if (overstock.length === 0) {
                            await pool.query(`insert into Overstock (storeID,sku,overstockQty) values(${storeID},"${sku}",${processQty});`)
                        } 
                        //If there is an overstock record we update it and add in the rest of the qty of the item that didnt fit in the aisle/shelf locations.
                        else {
                            var newQty = parseInt(overstock[0].overstockQty) + processQty;
                            await pool.query(`update Overstock set overstockQty=${newQty} where sku="${sku}" and storeID=${storeID};`)
                        }
                    }
                    
                }
                //If it all fits in the aisle/shelf location we just place it there.
                else {
                    var newQty = parseInt(currQty) + parseInt(processQty);
                    await pool.query(`update Placements set shelfQty=${newQty} where sku="${sku}" and storeID=${storeID} and aisle=${aisle} and shelf=${shelf};`)
                }
            }//end of inner for loop 
        }//end of outer for loop
        
        response = {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "POST"
            },
            body: JSON.stringify({
                message: "successful"
            })
        }
    } catch (err) {
        console.log(err);
        //return err;
        response = {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "POST",
            },
            body: JSON.stringify({
                error: err
            })
        }
    }

    return response
};
//-------------------------------------------------------


