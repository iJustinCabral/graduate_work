let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);


//-----------------------------------------------------------------
exports.handler = async (event, context, callback) => {
    
    try {
    let actual_event = event.body;
    let info = JSON.parse(actual_event);
    
    var stores = await pool.query(`select * from Stores;`);
    
    for(let i = 0; i< stores.length; i++){
    await insertItemPlacement(info.sku,stores[i].storeID, info.aisle, info.shelf);
    }
    
    var placements = await pool.query('select * from Placements;');

     response = {
            'statusCode': 200,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
                placements: placements
            })
        }
    } catch (err) { 
        console.log(err);
        //console.log("This executed");
        
         response = {
            'statusCode': 400,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};
//-----------------------------------------------------------------

async function insertItemPlacement (sku,storeID, aisle,shelf){
    var flag = await pool.query(`select * from Placements where sku="${sku}" AND storeID=${storeID} AND aisle=${aisle} AND shelf=${shelf};`);
    if(flag.length === 0){
    await pool.query(`insert into Placements (placementID,sku,storeID,aisle,shelf,shelfQty) values(NULL, "${sku}", ${storeID}, ${aisle},${shelf},0);`);
    }
}
