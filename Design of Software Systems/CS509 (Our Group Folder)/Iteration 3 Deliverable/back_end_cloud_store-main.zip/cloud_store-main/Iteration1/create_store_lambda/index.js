let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var config = require('./config.json')
var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
})

pool.query = util.promisify(pool.query);

exports.handler = async (event, context, callback) => {
    try {
        let actual_event = event.body;
        let info = JSON.parse(actual_event);
        
        var flag = await pool.query(`select * from Locations where longitude=${info.long} AND latitude=${info.lat};`);
        
        if(flag.length === 0){
        var result_location = await insertLocation(info.long, info.lat);
        var result_manager = await insertManager(info.username,info.password);
        var result_store = await insertStore(info.name, result_location.insertId, result_manager.insertId);
        
        response = {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "*"
            },
            body: JSON.stringify({
                result_store
            })
        }}
        else{
            response = {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "*",
            },
            body: JSON.stringify({
                error: "Duplicate Location"
            })
            }
        }
    } catch (err) {
        response = {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "*",
            },
            body: JSON.stringify({
                error: err
            })
        }
    }

    return response
};

function insertStore(name, locationID, managerID){
    var result = pool.query(`insert into Stores (name,locationID,managerID) values("${name}",${locationID},${managerID});`)
    return result
}

function insertLocation(long, lat) {
    var result = pool.query(`insert into Locations (locationID,longitude,latitude) values(NULL,${long},${lat})`)
    return result
}

function insertManager(username, password) {
    var result = pool.query(`insert into Managers (managerID,username,password) values(NULL,"${username}","${password}")`)
    return result
}
