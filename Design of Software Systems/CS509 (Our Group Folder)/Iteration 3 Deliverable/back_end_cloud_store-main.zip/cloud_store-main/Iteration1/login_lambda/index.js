let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var config = require('./config.json')
var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
})

pool.query = util.promisify(pool.query);

exports.handler = async (event, context, callback) => {
     try {
        let actual_event = event.body;
        let info = JSON.parse(actual_event);
        
        var whoAmI = info.whoAmI;
        
        //Search for corporate
        if(whoAmI === "corporate"){
            var flag = await pool.query(`select corporateID from Corporate where username="${info.username}" AND password="${info.password}";`);
            //if user is found
            if(flag.length != 0){
                response = {
                    statusCode: 200,
                    headers: {
                    "Access-Control-Allow-Headers" : "Content-Type",
                    "Access-Control-Allow-Origin" : "*",
                    "Access-Control-Allow-Methods" : "*"
                    },
                    body: JSON.stringify({
                    message: "successful login",
                    corporateID: flag[0].corporateID
                    })
        }}
        else{
            response = {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "*",
            },
            body: JSON.stringify({
                errorMessage: "User not found"
            })
            }
        }
        }
        //Search for manager
        else if(whoAmI === "manager"){
            var flag = await pool.query(`select managerID from Managers where username="${info.username}" AND password="${info.password}";`);
            //if user is found
            if(flag.length != 0){
                response = {
                    statusCode: 200,
                    headers: {
                    "Access-Control-Allow-Headers" : "Content-Type",
                    "Access-Control-Allow-Origin" : "*",
                    "Access-Control-Allow-Methods" : "*"
                    },
                    body: JSON.stringify({
                    message: "successful login",
                    managerID: flag[0].managerID
                    })
        }}
        else{
            response = {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "*",
            },
            body: JSON.stringify({
                errorMessage: "User not found"
            })
            }
        }
        }else{
            response = {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "*",
            },
            body: JSON.stringify({
                errorMessage: "User not found"
            })
            }
        }
    } catch (err) {
        response = {
            statusCode: 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "*",
            },
            body: JSON.stringify({
                error: err
            })
        }
    }

    return response
};