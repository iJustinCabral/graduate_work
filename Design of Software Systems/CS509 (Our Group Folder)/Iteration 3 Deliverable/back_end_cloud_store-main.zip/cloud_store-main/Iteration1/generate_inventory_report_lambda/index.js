let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);

//-----------------------------------------------------------------
exports.handler = async (event, context, callback) => {
    
    try {
    let actual_event = event.body;
    let info = JSON.parse(actual_event);
    var output = {};
    
    //Grab the store the manager belongs to.
    var store = await pool.query(`select * from Stores where managerID="${info.managerID}";`);
    var storeID = store[0].storeID;
    
    //Gets all items on the store floor
    var floorInventory = await generateFloorIventory(storeID);
    
    for(var i=0; i< floorInventory.length; i++){
        var item = await pool.query(`select * from Items where sku="${floorInventory[i].sku}";`);
        output[floorInventory[i].sku] = {
            itemName : item[0].name,
            price: item[0].price,
            qty: floorInventory[i].shelfQty,
            totalValue: parseFloat(item[0].price) * Number(floorInventory[i].shelfQty)
        };  
    }
    //console.log("Output 1:"+JSON.stringify(output));
    
    //Gets all items in the store's overstock
    var overstockInventory = await generateOverstockIventory(storeID);
    
    for(i=0; i< overstockInventory.length; i++){
        var itemPrice = output[overstockInventory[i].sku].price;
        
        output[overstockInventory[i].sku].qty += overstockInventory[i].overstockQty;
        output[overstockInventory[i].sku].totalValue += Number(overstockInventory[i].overstockQty) * parseFloat(itemPrice);
    }
    
    //console.log("Output 2:"+JSON.stringify(output));
    
     response = {
            'statusCode': 200,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
                inventory: output
            })
        }
    } catch (err) { 
        //console.log(err);
        //console.log("This executed");
        
         response = {
            'statusCode': 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "POST",
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};
//-----------------------------------------------------------------
//getsItems on store floor
function generateFloorIventory(storeID){
    var result = pool.query(`select * from Placements where storeID = ${storeID};`);
    return result;
}
//-----------------------------------------------------------------
//gets overstock Items
function generateOverstockIventory(storeID){
    var result = pool.query(`select * from Overstock where storeID = ${storeID};`);
    return result;
}