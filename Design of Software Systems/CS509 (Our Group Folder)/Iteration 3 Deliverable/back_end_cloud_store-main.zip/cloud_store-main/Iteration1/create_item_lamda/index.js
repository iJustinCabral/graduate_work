let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);

//-----------------------------------------------------------------
exports.handler = async (event, context, callback) => {
    
    try {
    let actual_event = event.body;
    let info = JSON.parse(actual_event);
    //console.log("info:" + JSON.stringify(info)); 
    
    var result = await insertItem(info.sku, info.name, info.description, info.price, info.shelfMaxQty);
    //console.log(result);
    
    var items = await pool.query('select * from Items;');
    
     response = {
            'statusCode': 200,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
                items: items
            })
        }
    } catch (err) { 
        //console.log(err);
        //console.log("This executed");
        
         response = {
            'statusCode': 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "POST",
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};
//-----------------------------------------------------------------

async function insertItem(sku,name,description,price,shelfMaxQty){
    var result = await pool.query(`insert into Items (sku,name,description,price,shelfMaxQty) values("${sku}", "${name}", "${description}", ${price},${shelfMaxQty});`);
    return result;
}

