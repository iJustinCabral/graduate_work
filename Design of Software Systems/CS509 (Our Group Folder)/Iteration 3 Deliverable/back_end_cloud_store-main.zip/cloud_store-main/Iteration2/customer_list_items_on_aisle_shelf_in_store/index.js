let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);

//-----------------------------------------------------------------
exports.handler = async (event, context, callback) => {
    
    try {
    let actual_event = event.body;
    let info = JSON.parse(actual_event);
    var output = {};
    
    //Grab the store and location.
    var storeID = info.storeID;
    var aisle = info.aisle;
    var shelf = info.shelf;
    
    //Gets all items in the store on the aisle/shelf locatioon
    //Rename overstock to itemsOnShelf
    var itemsOnShelf = await getItemsOnShelf(storeID,aisle,shelf);
    
    console.log(itemsOnShelf);
    
    for(var i=0; i< itemsOnShelf.length; i++){
        
        var item = await pool.query(`select * from Items where sku="${itemsOnShelf[i].sku}";`);
        output[i] = {
            itemName : item[0].name,
            itemDescription : item[0].description,
            price: item[0].price,
            qty: itemsOnShelf[i].shelfQty
        }; 
    }

     response = {
            'statusCode': 200,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
                ItemsOnShelf: output
            })
        }
    } catch (err) { 
        
         response = {
            'statusCode': 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "POST",
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};
//-----------------------------------------------------------------
//gets Items on aisle/shelf
function getItemsOnShelf(storeID,aisle,shelf){
    var result = pool.query(`select * from Placements where storeID = ${storeID} AND aisle = ${aisle} AND shelf = ${shelf};`);
    return result;
}