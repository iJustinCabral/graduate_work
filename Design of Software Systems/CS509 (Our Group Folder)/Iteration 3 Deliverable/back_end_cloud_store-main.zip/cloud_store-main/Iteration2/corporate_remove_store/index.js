let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);

//-----------------------------------------------------------------

exports.handler = async (event, context, callback) => {
    try {
        
    let actual_event = event.body;
    let info = JSON.parse(actual_event);
    
    var deleted = await pool.query(`delete from Stores where storeID=${info.storeID};`);
    
    console.log(deleted);

     response = {
            'statusCode': 200,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
                Message: deleted.affectedRows == 1 ? "Success" : "Didn't delete"
            })
        }
        
    } catch (err) { 
        console.log(err);
        
         response = {
            'statusCode': 400,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};

//-----------------------------------------------------------------
