let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);

//-----------------------------------------------------------------

exports.handler = async (event, context, callback) => {
    //************************************************* 
    try {
    let actual_event = event.body;
    let info = JSON.parse(actual_event);
    var output = [];
    
    var custLat = info.latitude;
    var custLong = info.longitude;
    
    var stores = await pool.query(`select * from Stores;`);
    
    for(var i=0; i< stores.length;i++){
        var location = await pool.query(`select * from Locations where locationID=${stores[i].locationID};`);
        
        var lat = location[0].latitude;
        var long = location[0].longitude;
        
        var distanceSpread = await distance(custLat, custLong, lat, long,"M");
        console.log(distanceSpread);
        
        output[i] = {
            storeID : stores[i].storeID,
            storeName : stores[i].name,
            latitude : lat,
            longitude : long,
            distance: distanceSpread
        }
    }
    //sort the stores
    output.sort((a,b) =>  a.distance - b.distance);
     response = {
            'statusCode': 200,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
                Stores: output
            })
        }
    //*************************************************    
    } catch (err) { 
        console.log(err);
        //console.log("This executed");
        
         response = {
            'statusCode': 400,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};

//-----------------------------------------------------------------
function distance (lat1, lon1, lat2, lon2, unit) {
    if ((lat1 == lat2) && (lon1 == lon2)) {
        return 0;
    }
    else {
        var radlat1 = Math.PI * lat1/180;
        var radlat2 = Math.PI * lat2/180;
        var theta = lon1-lon2;
        var radtheta = Math.PI * theta/180;
        var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
        if (dist > 1) {
            dist = 1;
        }
        dist = Math.acos(dist);
        dist = dist * 180/Math.PI;
        dist = dist * 60 * 1.1515;
        if (unit=="K") { dist = dist * 1.609344 }
        if (unit=="N") { dist = dist * 0.8684 }
        return dist;
    }
}
