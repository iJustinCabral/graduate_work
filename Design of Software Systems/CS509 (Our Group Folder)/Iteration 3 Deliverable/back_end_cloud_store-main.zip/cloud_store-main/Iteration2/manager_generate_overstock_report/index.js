let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);

//-----------------------------------------------------------------
exports.handler = async (event, context, callback) => {
    
    try {
    let actual_event = event.body;
    let info = JSON.parse(actual_event);
    var output = {};
    
    //Grab the store the manager belongs to.
    var store = await pool.query(`select * from Stores where managerID="${info.managerID}";`);
    var storeID = store[0].storeID;
    
    //Gets all items in the store's overstock
    var overstockInventory = await generateOverstockIventory(storeID);
    
    console.log(overstockInventory);
    
    for(var i=0; i< overstockInventory.length; i++){
        
        var item = await pool.query(`select * from Items where sku="${overstockInventory[i].sku}";`);
        output[overstockInventory[i].sku] = {
            itemName : item[0].name,
            price: item[0].price,
            qty: overstockInventory[i].overstockQty,
            totalValue: parseFloat(item[0].price) * Number(overstockInventory[i].overstockQty)
        }; 
    }
    
    
    
     response = {
            'statusCode': 200,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
                overstock: output
            })
        }
    } catch (err) { 
        
         response = {
            'statusCode': 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "POST",
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};
//-----------------------------------------------------------------
//gets overstock Items
function generateOverstockIventory(storeID){
    var result = pool.query(`select * from Overstock where storeID = ${storeID};`);
    return result;
}