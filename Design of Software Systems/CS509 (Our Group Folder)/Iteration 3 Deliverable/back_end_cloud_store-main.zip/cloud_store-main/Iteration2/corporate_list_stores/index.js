let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);

//-----------------------------------------------------------------

exports.handler = async (event, context, callback) => {
    //************************************************* 
    try {
    var stores = await pool.query(`select * from Stores;`);

     response = {
            'statusCode': 200,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
                Stores: stores
            })
        }
    //*************************************************    
    } catch (err) { 
        console.log(err);
        //console.log("This executed");
        
         response = {
            'statusCode': 400,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};

//-----------------------------------------------------------------