let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);

//-----------------------------------------------------------------
exports.handler = async (event, context, callback) => {
    try {
        
        var output = {};
        
        var stores = await pool.query(`select * from Stores;`);
        
        for (var i = 0; i < stores.length; i++) {
            var storeID = stores[i].storeID;
        
            //Gets all items on the store floor
            var floorInventory = await generateFloorIventory(storeID);
            
            for(var j=0; j< floorInventory.length; j++){
                var item = await pool.query(`select * from Items where sku="${floorInventory[j].sku}";`);
                
                if (floorInventory[j].sku in output) {
                    var itemPrice = output[floorInventory[j].sku].price;
                    
                    output[floorInventory[j].sku].qty += floorInventory[j].shelfQty;
                    output[floorInventory[j].sku].totalValue += Number(floorInventory[j].shelfQty) * parseFloat(itemPrice);
                } else {
                    output[floorInventory[j].sku] = {
                        itemName : item[0].name,
                        price: item[0].price,
                        qty: floorInventory[j].shelfQty,
                        totalValue: parseFloat(item[0].price) * Number(floorInventory[j].shelfQty)
                    };
                }
            }
            
            //Gets all items in the store's overstock
            var overstockInventory = await generateOverstockIventory(storeID);
            
            for(j=0; j< overstockInventory.length; j++){
                var itemPrice = output[overstockInventory[j].sku].price;
                
                output[overstockInventory[j].sku].qty += overstockInventory[j].overstockQty;
                output[overstockInventory[j].sku].totalValue += Number(overstockInventory[j].overstockQty) * parseFloat(itemPrice);
            }
        }

        response = {
            'statusCode': 200,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
                storesInventory: output
            })
        }
    } catch (err) { 
        console.log(err);
        
         response = {
            'statusCode': 400,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};

//-----------------------------------------------------------------
//getsItems on store floor
function generateFloorIventory(storeID){
    var result = pool.query(`select * from Placements where storeID = ${storeID};`);
    return result;
}
//-----------------------------------------------------------------
//gets overstock Items
function generateOverstockIventory(storeID){
    var result = pool.query(`select * from Overstock where storeID = ${storeID};`);
    return result;
}
