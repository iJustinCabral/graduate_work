let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);

//-----------------------------------------------------------------
exports.handler = async (event, context, callback) => {
    try {
        let actual_event = event.body;
        let info = JSON.parse(actual_event);
        
        var sku = info.sku;
        var qtyToBuy = info.qty;
        var storeID = info.storeID;
        
        var returnBool = await buyItem(sku, qtyToBuy, storeID);
        
        if (returnBool === true) {
            
            response = {
                'statusCode': 200,
                headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "POST"
                },
                'body': JSON.stringify({
                    Response: "Buy Successful"
                })
            }
        } else {
            response = {
                'statusCode': 400,
                headers: {
                    "Access-Control-Allow-Headers" : "Content-Type",
                    "Access-Control-Allow-Origin" : "*",
                    "Access-Control-Allow-Methods" : "POST",
                },
                'body': JSON.stringify({
                    Response: "Buy Failed"
                })
            }
        }
        
    } catch (err) { 
         response = {
            'statusCode': 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "POST",
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};
//-----------------------------------------------------------------
async function buyItem(sku,qtyToBuy,storeID) {
   var storePlacement = await pool.query(`select * from Placements where sku="${sku}" AND storeID=${storeID};`);
   
   if(qtyToBuy <= storePlacement[0].shelfQty){
       
       var newShelfQty = Number(storePlacement[0].shelfQty) - Number(qtyToBuy);
       
       var response = await pool.query(`Update Placements Set shelfQty = ${newShelfQty} where sku="${sku}" AND storeID=${storeID};`);
      
       return true;
   }
   else{
       return false;
   }
   
}