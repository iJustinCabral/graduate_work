let response;
const mysql = require('mysql');
var config = require('./config.json');
var util = require('util');

var pool = mysql.createPool({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database
});

pool.query = util.promisify(pool.query);

//-----------------------------------------------------------------
exports.handler = async (event, context, callback) => {
    
    try {
        let actual_event = event.body;
        let info = JSON.parse(actual_event);
        var output = [];
        
        //Grab the store the manager belongs to.
        var store = await pool.query(`select * from Stores where managerID="${info.managerID}";`);
        var storeID = store[0].storeID;
        
        //Gets all items on the store floor
        var floorInventory = await generateFloorIventory(storeID);
        console.log("Floor:"+JSON.stringify(floorInventory));
        
        for(var i = 0; i < floorInventory.length; i++) {
            var itemFloorPlacement = floorInventory[i];
            var item = await pool.query(`select * from Items where sku="${floorInventory[i].sku}";`);
            
            //if there is room on the shelf fill it
            if (itemFloorPlacement.shelfQty < item[0].shelfMaxQty) {
                
                var fillShelfResult = await fillShelf(storeID,itemFloorPlacement,item[0])
                output[i]= fillShelfResult;
            }
            //if there is no room on the shelf skip
            else{
                output[i]={
                    itemName: item[0].name,
                    storeID: storeID,
                    aisle: itemFloorPlacement.aisle,
                    shelf: itemFloorPlacement.shelf,
                    shelfQty: itemFloorPlacement.shelfQty,
                    message: "Shelf qty is at maxQty."
                    
                };
            }
        }
 
        
        
        response = {
            'statusCode': 200,
            headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "POST"
            },
            'body': JSON.stringify({
                Response: output
            })
        }
    } catch (err) { 
        
         response = {
            'statusCode': 400,
            headers: {
                "Access-Control-Allow-Headers" : "Content-Type",
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Methods" : "POST",
            },
            'body': JSON.stringify({
            error: err
            })
        }
        
    }
  
    return response;
};
//-----------------------------------------------------------------
//getsItems on store floor
function generateFloorIventory(storeID){
    var result = pool.query(`select * from Placements where storeID = ${storeID};`);
    return result;
}
//-----------------------------------------------------------------
//fill Shelf in store
async function fillShelf(storeID,itemPlacement,item){
    var result;
    console.log(`storeID: ${storeID}, itemSKU: ${item.sku}`)
    var overstockInventory = await pool.query(`select * from Overstock where storeID = ${storeID} and sku="${item.sku}";`);
    console.log(overstockInventory);
    
    //if there isnt anything in overstock for the item.
    if(overstockInventory.length == 0){
        result = {
            itemName: item.name,
            storeID: storeID,
            aisle: itemPlacement.aisle,
            shelf: itemPlacement.shelf,
            message: "Nothing in overstock"
        };
    }
    //if there is stuff in overstock for the item.
    else{
        var overstockInstance = overstockInventory[0];
        var numThatCanBeAddedToShelf = parseInt(item.shelfMaxQty) - parseInt(itemPlacement.shelfQty);
        
        //if the amount in overstock is less than or equal to the amount of space left on the shelf, add it all and set overstock qty to zero.
        if(overstockInstance.overstockQty <= numThatCanBeAddedToShelf){
            var newShelfQty = overstockInstance.overstockQty;
            var newOverstockQty = 0;
            await pool.query(`Update Placements Set shelfQty = ${newShelfQty} where sku="${item.sku}" AND storeID=${storeID};`);
            await pool.query(`Update Overstock Set overstockQty = ${newOverstockQty} where sku="${item.sku}" AND storeID=${storeID};`);
            result = result = {
                itemName: item.name,
                storeID: storeID,
                aisle: itemPlacement.aisle,
                shelf: itemPlacement.shelf,
                message: "All of overstock for item placed on shelf"
            };
        }
         //if the amount in overstock is greater than the amount of space left on the shelf, add what fits until max and substract that from overstock.
        else{
            var newShelfQty = numThatCanBeAddedToShelf + parseInt(itemPlacement.shelfQty);
            var newOverstockQty = parseInt(overstockInstance.overstockQty) - numThatCanBeAddedToShelf;
            await pool.query(`Update Placements Set shelfQty = ${newShelfQty} where sku="${item.sku}" AND storeID=${storeID};`);
            await pool.query(`Update Overstock Set overstockQty = ${newOverstockQty} where sku="${item.sku}" AND storeID=${storeID};`);
            result = result = result = {
                itemName: item.name,
                storeID: storeID,
                aisle: itemPlacement.aisle,
                shelf: itemPlacement.shelf,
                message: "Shelf filled and overstock updated"
            };
        }
     
    }
    
    return result;
}